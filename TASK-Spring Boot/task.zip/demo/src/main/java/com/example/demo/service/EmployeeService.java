package com.example.demo.service;

import com.example.demo.dto.Employee;
import org.springframework.stereotype.Service;

@Service
public interface EmployeeService {

    public Employee addEmployee(Employee employee);


}
