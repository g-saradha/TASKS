package com.example.demo.dto;

public class Employee {

    private int EmployeeIdNo;

    private String EmployeeName;

    public Employee() {
    }

    public Employee(int employeeIdNo, String employeeName) {
        EmployeeIdNo = employeeIdNo;
        EmployeeName = employeeName;
    }

    public int getEmployeeIdNo() {
        return EmployeeIdNo;
    }

    public void setEmployeeIdNo(int employeeIdNo) {
        EmployeeIdNo = employeeIdNo;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String employeeName) {
        EmployeeName = employeeName;
    }
}
